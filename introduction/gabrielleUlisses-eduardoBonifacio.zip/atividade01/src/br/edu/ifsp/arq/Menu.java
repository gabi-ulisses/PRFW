package br.edu.ifsp.arq;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu {
    public static void main(String[] args) {
        List<Cardapio> itens = new ArrayList<>();
        
        itens.add(new Cardapio("Arroz", 5.0));
        itens.add(new Cardapio("Feijão", 2.0));
        itens.add(new Cardapio("Batata", 1.0));
        itens.add(new Cardapio("Cenoura", 1.50));

        Scanner ler = new Scanner(System.in);
        int opcao;
        double valorTotal = 0;

        while (true) {
        	
            System.out.println("\n Cardápio \n");
            for (int i = 0; i < itens.size(); i++) {
                System.out.println(i + " - " + itens.get(i).toString());
            }
            System.out.println(itens.size() + " - Fechar conta");
            System.out.print("\nEscolha sua opção: ");
            
            opcao = ler.nextInt();

            if (opcao == itens.size()) {
                System.out.println("\nConta fechada.");
                break;
            }

            if (opcao < 0 || opcao > itens.size()) {
                System.out.println("Opção inválida!");
                continue;
            }

            valorTotal += itens.get(opcao).getValor();
            System.out.print("\nTotal parcial: R$" + valorTotal + "\n");
        }

        System.out.print("\nTotal final: R$" + valorTotal + "\n");
        ler.close();
    }
}