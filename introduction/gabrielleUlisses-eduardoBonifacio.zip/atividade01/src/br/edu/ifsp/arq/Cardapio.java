package br.edu.ifsp.arq;

public class Cardapio {
	
	private String item;
	private double valor;
	
	public Cardapio(String item, double valor){
		setItem(item);
		setValor(valor);
	}

	public String getItem() {
		return item;
	}

	private void setItem(String item) {
		this.item = item;
	}

	public double getValor() {
		return valor;
	}

	private void setValor(double valor) {
		if(valor < 0) {
			throw new IllegalArgumentException("O valor não pode ser negativo.");
		}else {
			this.valor = valor;
		}
	}
	
	@Override
	public String toString() {
		return getItem() + " - R$" + getValor();
	}
	
}
